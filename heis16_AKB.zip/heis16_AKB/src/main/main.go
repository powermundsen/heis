package main
import "elevator"

func main(){
	driver.Elevator_init()
}